import React from 'react'
import Header from './Header'

export default function About() {
  return(
    <>
        <Header/>
        <h1>¡Muchas gracias por aplazarme el examen y por ser tan buena gente!</h1>
        <br></br>
        <h1>Te lo agradezco de corazón</h1>
    </>
  );
}