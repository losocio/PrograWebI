import React from 'react'
import Navbar from './Navbar'

export default function About() {
  return (
    <>
        <Navbar/>
        <h1>Este es el about</h1>
    </>
  )
}